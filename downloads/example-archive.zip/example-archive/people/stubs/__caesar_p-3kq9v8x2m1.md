---
id: p-3kq9v8x2m1
aliases: [p-3kq9v8x2m1]
name: Caesar
surname: ""   # set by hand: no surname, the file name leads with __
sex: M
living: false
# birth:   # an honest guess is fine - a tool will remind you to add a source later
# death:   # same here; leave commented until you know
created: 2026-06-29
tier: stub
---

# Caesar

> **This person's record - yours to write.** The main page for this person: summary,
> biography, relationships. The summary lines under this note and the `## Sources`
> list are generated - `fha views refresh` rewrites them, so never edit them by hand.
> Everything else here is yours; working notes go in `## Research Notes` below, or in
> a separate `_research` file if this person's research grows large enough to want one
> of its own.

## Sources
*(none yet - regenerate with `fha views sources-index`.)*

## Biography
Recorded only as "Caesar" in the 1849 probate inventory of the Hartley estate. A stub kept
so the archive remembers him while the inventory is found and filed.

## Stories
*(none yet)*

## Research Notes
Open questions, hunches, and brick walls - where to look next. (Delete this line
as you add your own.) This section is public by default.
<!-- To keep one note out of anything you share, put it between two marker
     lines: before it, the word private inside marks like the ones around this
     note; after it, /private the same way. START_HERE.md shows both lines.
     The note stays in your own archive and your local preview. -->

## Friends & Family
People connected to them who aren't blood relatives - neighbors, business
partners, the family they boarded with. Type [[ and pick a name to link.
